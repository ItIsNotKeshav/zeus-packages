<p align="center">
  <img src="docs/assets/images/logo.svg" alt="Zeus logo" width="96" height="96">
</p>

<h1 align="center">Zeus</h1>

<p align="center"><strong>WhatsApp, native and fast.</strong><br>A lightweight desktop WhatsApp client for Windows, macOS, and Linux.</p>

<p align="center">
  <a href="https://github.com/ItIsNotKeshav/zapfast/releases/latest"><strong>Download</strong></a> ·
  <a href="#install">Install</a> ·
  <a href="#link-your-phone">Link your phone</a> ·
  <a href="#credits">Credits</a> ·
  <a href="CODE_SIGNING.md">Code signing policy</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Built_with-Rust-24292f" alt="Built with Rust">
  <img src="https://img.shields.io/badge/Windows_%C2%B7_macOS_%C2%B7_Linux-24292f" alt="Windows, macOS, and Linux">
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-24292f" alt="MIT license"></a>
  <a href="https://github.com/ItIsNotKeshav/Zeus/releases"><img src="https://img.shields.io/github/downloads/ItIsNotKeshav/Zeus/total?label=Downloads&color=24292f" alt="Total downloads"></a>
</p>

Zeus is a fork of [ZapFast](https://github.com/crmne/zapfast) by
[Carmine Paolino](https://github.com/crmne). It is a native WhatsApp app
written in Rust with [egui](https://www.egui.rs), with no browser engine
inside. It links to your phone as a companion device, the way WhatsApp Web
does, and keeps your chats in an encrypted archive on your own computer.

<p align="center">
  <img src="docs/readme/chat-dark.png" alt="Zeus in its Dark theme on a MacBook, showing a conversation with a photo, a file, voice messages, a quoted reply, and a link preview">
</p>

<p align="center"><em>The screenshots use made-up demo chats, never real conversations.</em></p>

## Your look

Nine themes, each in light and dark, with an accent of your own that works on
every one of them. Frosted panels with blur you can switch off, doodle
wallpapers in several styles, and an app icon to match.

<p align="center">
  <img src="docs/readme/chat-light.png" alt="Zeus's Light theme" width="49%">
  <img src="docs/readme/chat-dracula.png" alt="Zeus with the Dracula theme" width="49%">
</p>
<p align="center">
  <img src="docs/readme/chat-catppuccin.png" alt="Zeus with the Catppuccin theme" width="49%">
  <img src="docs/readme/chat-nord.png" alt="Zeus with the Nord theme" width="49%">
</p>
<p align="center">
  <img src="docs/readme/chat-messages.png" alt="Zeus with the Messages look, with its own bubble shapes" width="49%">
  <img src="docs/readme/doodles.png" alt="Zeus in the Light theme with accent-coloured travel doodles" width="49%">
</p>

## Chats that feel good

Frosted composer, attachment previews while files send, reactions you can pick
from the message, and a message menu with Reply, Edit, Forward, Pin and more.

<p align="center">
  <img src="docs/readme/composer.png" alt="Zeus's composer with its attachment and poll menu open" width="49%">
  <img src="docs/readme/reactions.png" alt="Zeus's reaction picker and messages with reactions" width="49%">
</p>

PDFs open in Zeus's own reader, a card that flies out of the message and
keeps your place. Searching a chat opens in a frosted card beside it, and
YouTube and Instagram links show their picture.

<p align="center">
  <img src="docs/readme/pdf.png" alt="A PDF open in Zeus's built-in reader, in the Catppuccin theme" width="49%">
  <img src="docs/readme/chat-search.png" alt="Searching a chat in Zeus, the results in a frosted card beside the conversation" width="49%">
</p>

## Settings

Your account up front, then Appearance, Chats, Notifications, Calls and
voice, Storage and General, each group of options on its own card. Pick your
microphone and camera (with a live preview), turn on push to talk, and choose
the app icon.

<p align="center">
  <img src="docs/readme/settings-appearance.png" alt="Zeus Settings, Appearance: a theme previewed on a chat, theme tiles, accents, mode and Glass" width="49%">
  <img src="docs/readme/settings-chats.png" alt="Zeus Settings, Chats, in the Light theme" width="49%">
</p>
<p align="center">
  <img src="docs/readme/settings-notifications.png" alt="Zeus Settings, Notifications, in the Dracula theme" width="49%">
  <img src="docs/readme/settings-camera.png" alt="Zeus Settings, Calls and voice: microphone, camera with a live preview, and push to talk" width="49%">
</p>
<p align="center">
  <img src="docs/readme/settings-app-icon.png" alt="Zeus Settings: the app icon picker with fourteen bolt-Z icons, in the Light theme" width="49%">
</p>

## What Zeus is

Zeus is ZapFast, tuned for everyday use. It already ships ZapFast's new voice
and video calls, and adds its own touches on top:

- **Better calls.** Pick your microphone once in Settings, and hold a key to
  talk when the room is noisy.
- **Your colours.** Nine themes, each in light and dark, with your own accent
  on top. Frosted bars, with blur you can switch off.
- **Clearer chats.** Photos and files show a preview and progress while they
  send, times can stay on every message, and sent messages fly in from the
  composer.
- **Beside ZapFast, not over it.** Its own Windows installer, folders,
  settings and linked devices, so both can run.

Everything else comes from ZapFast: formatting, replies, edits, reactions,
media, stickers, GIFs, polls, voice messages, several numbers in one window,
locked chats, an app lock, and tray notifications, in ten languages.

## Install

| Platform | How |
|---|---|
| **Windows** | Download `zeus-v<version>-x86_64-pc-windows-msvc-setup.exe` from [Releases](https://github.com/ItIsNotKeshav/zapfast/releases/latest). It installs for your user without administrator rights and updates itself from then on. It is not code-signed, so Windows SmartScreen warns once: choose **More info**, then **Run anyway**. |
| **macOS** | Download `zeus-v<version>-macos-universal.dmg` (Apple Silicon and Intel), open it and drag Zeus to Applications. The app is not signed by Apple, so the first time, right-click Zeus in Applications and choose **Open**. |
| **Linux** | Download the `.deb`, `.rpm`, AppImage or `.tar.gz` for x86_64 or aarch64. The AppImage and `.tar.gz` update themselves; `.deb` and `.rpm` update through a new download. |
| **From source** | Install Rust, then run `cargo build --release --locked`. Linux needs ALSA, PipeWire, and clang headers, and every platform needs cmake. |

Only the Windows build is tested by the maintainer. The macOS and Linux builds
are produced by GitHub Actions and are not yet tried on real machines, so
please report what you find.

## Link your phone

1. Open Zeus. It shows a QR code.
2. On your phone, open WhatsApp, go to **Linked devices**, and choose **Link a device**.
3. Scan the code. Your recent chats appear, and Zeus asks your phone for older history as you scroll.

Zeus is a companion device, so your phone remains the main account. Your chats
stay in an encrypted archive on this computer, and nothing goes to a server
of ours.

## Guides

New to Zeus? The [user guide](USER-GUIDE.md) covers installing, linking your
phone and everyday use.

Zeus shares ZapFast's behaviour, so the
[ZapFast guides](https://zapfast.rocks/) apply: how linking works, settings
and stored files, shortcuts, and making your own theme. Their screenshots show
ZapFast's name and colours.

## Credits

Zeus exists because of [ZapFast](https://github.com/crmne/zapfast), created
and maintained by **Carmine Paolino** ([@crmne](https://github.com/crmne)) and
its [contributors](https://github.com/crmne/zapfast/graphs/contributors).
The app, its design, and almost all of its code are their work. Please
[star and support the original project](https://github.com/crmne/zapfast).

Zeus also builds on:

- [whatsapp-rust](https://github.com/oxidezap/whatsapp-rust) for the WhatsApp protocol
- [egui](https://www.egui.rs) and [fastframe](https://fastframe.dev) for the interface and desktop integration
- the open-source libraries listed in [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)

## Disclaimer

Zeus is an unofficial client. It is not affiliated with, endorsed by, or
connected to WhatsApp or Meta. Use it at your own risk: WhatsApp can limit
accounts that use unofficial clients.

## License

MIT. Copyright (c) 2026 Carmine Paolino, and Keshav for the changes in this
fork. See [LICENSE](LICENSE).
